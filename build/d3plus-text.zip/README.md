# d3plus-textbox

[![NPM Release](http://img.shields.io/npm/v/d3plus-textbox.svg?style=flat-square)](https://www.npmjs.org/package/d3plus-textbox)
[![Build Status](https://travis-ci.org/d3plus/d3plus-textbox.svg?branch=master)](https://travis-ci.org/d3plus/d3plus-textbox)
[![Dependency Status](http://img.shields.io/david/d3plus/d3plus-textbox.svg?style=flat-square)](https://david-dm.org/d3plus/d3plus-textbox)
[![Dependency Status](http://img.shields.io/david/dev/d3plus/d3plus-textbox.svg?style=flat-square)](https://david-dm.org/d3plus/d3plus-textbox#info=devDependencies)

